import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Compass,
  GraduationCap,
  LogOut,
  MessageSquare,
  Mic,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  UserPlus,
  Users,
} from 'lucide-react';
import { AuthenticatedAudioPlayer, AuthenticatedVideoPlayer } from './AuthenticatedMedia';
import type {
  AdminContentConfig,
  AuthUser,
  PlayerProgress,
  TeacherVoiceRecord,
  UserRole,
} from '../types/game';

interface TeacherPortalProps {
  user: AuthUser;
  token: string;
  onEnterWorld3D: () => void;
  onLogout: () => void;
}

export const TeacherPortal: React.FC<TeacherPortalProps> = ({
  user,
  token,
  onEnterWorld3D,
  onLogout,
}) => {
  const [students, setStudents] = useState<Array<{ user: AuthUser; progress: PlayerProgress }>>([]);
  const [voiceRecords, setVoiceRecords] = useState<TeacherVoiceRecord[]>([]);
  const [voiceRecordsLoading, setVoiceRecordsLoading] = useState<boolean>(true);
  const [selectedId, setSelectedId] = useState<string>('');
  const [comment, setComment] = useState('');
  const [ratingLabel, setRatingLabel] = useState<
    'Sedang Dibimbing' | 'Memuaskan' | 'Baik' | 'Cemerlang'
  >('Baik');
  const [saveMsg, setSaveMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const loadTeacherData = async () => {
    setErrorMsg('');
    setVoiceRecordsLoading(true);
    try {
      const [stuRes, voiceRes] = await Promise.all([
        fetch('/api/teacher/students', {
          headers: { Authorization: `Bearer ${token}` },
        }),
        fetch('/api/teacher/voice-records', {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      if (!stuRes.ok) {
        const d = (await stuRes.json()) as { error?: string };
        setErrorMsg(d.error || 'Gagal memuatkan rekod murid.');
      } else {
        const data = (await stuRes.json()) as {
          students: Array<{ user: AuthUser; progress: PlayerProgress }>;
        };
        setStudents(data.students);
        if (!selectedId && data.students.length > 0) {
          setSelectedId(data.students[0].user.id);
        }
      }

      if (voiceRes.ok) {
        const vData = (await voiceRes.json()) as { records: TeacherVoiceRecord[] };
        setVoiceRecords(vData.records || []);
      }
    } catch {
      setErrorMsg('Sambungan pelayan terganggu semasa memuatkan rekod Portal Guru.');
    } finally {
      setVoiceRecordsLoading(false);
    }
  };

  useEffect(() => {
    void loadTeacherData();
  }, []);

  const activeStudent = students.find((s) => s.user.id === selectedId);

  useEffect(() => {
    if (activeStudent?.progress.teacherFeedback) {
      setComment(activeStudent.progress.teacherFeedback.comment);
      setRatingLabel(activeStudent.progress.teacherFeedback.ratingLabel);
    } else {
      setComment('');
      setRatingLabel('Baik');
    }
    setSaveMsg('');
  }, [selectedId]);

  const handleSubmitFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStudent) return;
    setSaveMsg('');
    const res = await fetch('/api/teacher/feedback', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        studentUserId: activeStudent.user.id,
        comment,
        ratingLabel,
      }),
    });
    if (res.ok) {
      setSaveMsg('Maklum balas guru berjaya disimpan dan dipaparkan kepada murid.');
      await loadTeacherData();
    }
  };

  return (
    <div className="min-h-screen w-full overflow-y-auto bg-[#162038] text-[#FAF6EE]">
      <header className="border-b border-[#D4AF37]/25 bg-[#1B2948] px-6 py-4 flex items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <GraduationCap className="w-6 h-6 text-[#D4AF37]" />
          <div>
            <h1 className="font-display text-lg font-semibold text-[#FAF6EE]">
              Portal Guru · Kingdom of Stories
            </h1>
            <p className="text-xs text-[#C8B6E2]">
              {user.fullName} · Kelas {user.className || '5 Bestari'}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onEnterWorld3D}
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#E5C35A] bg-[#233256] text-xs font-semibold text-[#E5C35A] hover:bg-[#2C3F6C]"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Masuk Dunia 3D</span>
          </button>
          <button
            type="button"
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#FAF6EE]/20 bg-[#162038] text-xs font-semibold hover:bg-[#233256]"
          >
            <LogOut className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Log Keluar</span>
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Royal 3D Preview Entry Card */}
        <section className="lg:col-span-12 rounded-2xl border border-[#D4AF37]/40 bg-gradient-to-r from-[#172347] via-[#1F2C58] to-[#172347] p-5 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#E5C35A]">
              <Sparkles className="w-4 h-4" />
              <span>Dunia 3D Kingdom of Stories · Kesemua 5 Misi Terbuka</span>
            </div>
            <h2 className="font-display text-lg font-bold text-[#FAF6EE]">
              Pratonton Persekitaran &amp; Aliran 5 Misi
            </h2>
            <p className="text-xs sm:text-sm text-[#EFE6D5]/85">
              Masuki kesemua lima lokasi misi pada bila-bila masa untuk meninjau persekitaran 3D, aktiviti dan aliran permainan dalam keadaan pratonton tanpa mengubah rekod murid.
            </p>
          </div>
          <button
            type="button"
            onClick={onEnterWorld3D}
            className="px-5 py-2.5 rounded-xl bg-[#D4AF37] text-[#162038] text-xs font-bold hover:bg-[#E5C35A] transition-colors whitespace-nowrap shrink-0"
          >
            Masuk Dunia 3D (5 Misi Terbuka)
          </button>
        </section>

        {errorMsg && (
          <div className="lg:col-span-12 rounded-xl border border-red-400/40 bg-red-950/40 p-4 text-sm text-red-200">
            {errorMsg}
          </div>
        )}

        {/* Dedicated Misi 4 Student Voice Recordings Repository */}
        <section className="lg:col-span-12 rounded-2xl border border-[#7BE0E6]/35 bg-[#1B2948] p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#FAF6EE]/10 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <Mic className="w-5 h-5 text-[#D4AF37]" />
                <h2 className="font-display text-lg font-bold text-[#FAF6EE]">
                  Rekod Rakaman Suara Murid
                </h2>
                <span className="rounded-md border border-[#7BE0E6]/40 bg-[#121D3B] px-2.5 py-0.5 text-xs font-semibold text-[#7BE0E6]">
                  {voiceRecords.length} Rakaman
                </span>
              </div>
              <p className="text-xs text-[#C8B6E2] mt-1">
                Semua rakaman suara sebenar murid daripada Misi 4: Balai Gema Diraja disimpan secara kekal untuk dimainkan terus atau dimuat turun oleh pensyarah.
              </p>
            </div>
            <button
              type="button"
              onClick={() => void loadTeacherData()}
              disabled={voiceRecordsLoading}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-[#FAF6EE]/20 bg-[#162038] text-xs font-semibold text-[#FAF6EE] hover:bg-[#233256] disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#D4AF37] ${voiceRecordsLoading ? 'animate-spin' : ''}`} />
              <span>Muat Semula Senarai</span>
            </button>
          </div>

          {voiceRecordsLoading ? (
            <div className="rounded-xl bg-[#162038] border border-[#FAF6EE]/10 p-5 text-xs text-[#C8B6E2]">
              Memuatkan rekod rakaman suara murid...
            </div>
          ) : voiceRecords.length === 0 ? (
            <div className="rounded-xl bg-[#162038] border border-[#FAF6EE]/10 p-5 text-xs sm:text-sm text-[#EFE6D5]/75">
              Belum ada rakaman suara yang dihantar oleh murid bagi Misi 4: Balai Gema Diraja. Sebaik sahaja murid menekan &quot;Simpan Rakaman&quot;, fail audio akan dipaparkan di sini secara automatik.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {voiceRecords.map((rec) => (
                <div
                  key={`${rec.studentUserId}-${rec.mediaId}`}
                  className="rounded-xl border border-[#D4AF37]/30 bg-[#162038] p-4 space-y-3"
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <div className="font-semibold text-sm text-[#FAF6EE]">{rec.studentName}</div>
                      <div className="text-xs text-[#C8B6E2]">
                        Kelas {rec.className} · @{rec.studentUsername}
                      </div>
                    </div>
                    <span className="inline-flex items-center gap-1 rounded-md border border-[#6EE7B7]/45 bg-[#12333E] px-2.5 py-0.5 text-[11px] font-semibold text-[#6EE7B7]">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>{rec.submissionStatus}</span>
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 rounded-lg bg-[#101930] border border-[#FAF6EE]/10 p-2.5 text-[11px] text-[#EFE6D5]">
                    <div>
                      <span className="text-[#8FBCE0]">Misi:</span>{' '}
                      <strong className="text-[#FAF6EE]">{rec.missionName}</strong>
                    </div>
                    <div>
                      <span className="text-[#8FBCE0]">Cubaan &amp; Tempoh:</span>{' '}
                      <strong className="text-[#D4AF37]">
                        Cubaan ke-{rec.attemptNumber} ({rec.durationSeconds}s)
                      </strong>
                    </div>
                    <div className="col-span-2">
                      <span className="text-[#8FBCE0]">Tarikh Rakaman:</span>{' '}
                      <span className="text-[#FAF6EE]">
                        {new Date(rec.recordedAt).toLocaleString('ms-MY', {
                          dateStyle: 'medium',
                          timeStyle: 'short',
                        })}
                      </span>
                    </div>
                  </div>

                  <AuthenticatedAudioPlayer
                    mediaId={rec.mediaId}
                    token={token}
                    downloadFilename={`${rec.studentUsername}-misi4-cubaan${rec.attemptNumber}-${rec.filename}`}
                    showDownloadButton
                  />

                  {rec.transcript && (
                    <p className="text-xs text-[#EFE6D5]/80 bg-[#121B35] rounded-lg p-2.5 border border-[#FAF6EE]/10">
                      <strong className="text-[#C8B6E2]">Catatan / Transkripsi:</strong>{' '}
                      {rec.transcript}
                    </p>
                  )}

                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => setSelectedId(rec.studentUserId)}
                      className="text-[11px] font-semibold text-[#7BE0E6] hover:underline"
                    >
                      Lihat &amp; Nilai Rekod {rec.studentName} →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Left Student Roster */}
        <section className="lg:col-span-4 space-y-3">
          <h2 className="text-sm font-semibold text-[#D4AF37]">
            Senarai Murid ({students.length})
          </h2>
          <div className="space-y-2">
            {students.map(({ user: stu, progress }) => (
              <button
                key={stu.id}
                onClick={() => setSelectedId(stu.id)}
                className={`w-full text-left rounded-xl border p-4 transition-colors ${
                  selectedId === stu.id
                    ? 'border-[#D4AF37] bg-[#233256]'
                    : 'border-[#FAF6EE]/15 bg-[#1B2948] hover:border-[#C8B6E2]/50'
                }`}
              >
                <div className="font-semibold text-sm text-[#FAF6EE]">{stu.fullName}</div>
                <div className="text-xs text-[#C8B6E2] mt-1">
                  Kelas {progress.className} · {progress.completedMissions.length}/5 Misi Selesai
                </div>
                <div className="text-[11px] text-[#8FBCE0] mt-1">
                  Tahap Adaptif: {progress.adaptiveLevel}
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Right Student Evidence & Assessment */}
        <section className="lg:col-span-8">
          {activeStudent ? (
            <div className="rounded-2xl border border-[#D4AF37]/30 bg-[#1B2948] p-6 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#FAF6EE]/10 pb-4">
                <div>
                  <h2 className="font-display text-xl text-[#FAF6EE]">
                    {activeStudent.user.fullName}
                  </h2>
                  <p className="text-xs text-[#C8B6E2]">
                    Misi Selesai: {activeStudent.progress.completedMissions.length}/5 · Fragmen:{' '}
                    {activeStudent.progress.collectedFragmentIds.length}/5 · Lencana:{' '}
                    {activeStudent.progress.achievements.filter((a) => a.unlockedAt).length}
                  </p>
                </div>
                <span className="text-xs font-semibold text-[#7FA88C] flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {activeStudent.progress.festivalUnlocked
                      ? 'Projek Lengkap'
                      : 'Sedang Melaksanakan Misi'}
                  </span>
                </span>
              </div>

              {/* Script Review */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-[#D4AF37]">
                  Skrip Penceritaan Digital Murid
                </h3>
                <div className="rounded-xl bg-[#162038] border border-[#FAF6EE]/10 p-4 text-xs sm:text-sm leading-relaxed text-[#EFE6D5]">
                  {activeStudent.progress.scriptPlan.fullScript}
                </div>
                {activeStudent.progress.languageFeedback && (
                  <p className="text-xs text-[#8FBCE0]">
                    Ringkasan Mentor Bahasa AI: {activeStudent.progress.languageFeedback.summary}
                  </p>
                )}
              </div>

              {/* Authorized Private Voice Recordings */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-[#8FBCE0]">
                  Rakaman Suara Murid — Misi 4: Balai Gema Diraja
                </h3>
                {activeStudent.progress.voiceAttempts.length === 0 ? (
                  <p className="text-xs text-[#FAF6EE]/60">Murid belum menghantar rakaman suara.</p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {activeStudent.progress.voiceAttempts.map((va) => (
                      <div
                        key={va.attemptNumber}
                        className="rounded-xl bg-[#162038] border border-[#FAF6EE]/15 p-3 space-y-2"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-[#D4AF37]">
                            Cubaan ke-{va.attemptNumber} ({va.durationSeconds}s)
                          </span>
                          <span className="text-[11px] text-[#6EE7B7]">
                            {va.submissionStatus || 'Berjaya Dihantar'}
                          </span>
                        </div>
                        <AuthenticatedAudioPlayer
                          mediaId={va.mediaId}
                          token={token}
                          downloadFilename={`${activeStudent.user.username}-misi4-cubaan${va.attemptNumber}.webm`}
                          showDownloadButton
                        />
                        <p className="text-xs text-[#EFE6D5]/80">{va.transcript}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Final Submitted Video */}
              <div className="space-y-2">
                <h3 className="text-sm font-semibold text-[#C8B6E2]">
                  Penyerahan Video Akhir ("Misi Menyelamatkan Taman Sekolah")
                </h3>
                {activeStudent.progress.finalVideoMediaId ? (
                  <AuthenticatedVideoPlayer
                    mediaId={activeStudent.progress.finalVideoMediaId}
                    token={token}
                    className="w-full max-h-64 rounded-xl bg-black"
                  />
                ) : activeStudent.progress.theatreCompleted ? (
                  <div className="rounded-lg bg-[#162038] p-3 text-xs text-[#EFE6D5]">
                    Murid mempersembahkan Mod Papan Cerita Berpandu:{' '}
                    <strong>{activeStudent.progress.finalVideoTitle}</strong>
                  </div>
                ) : (
                  <p className="text-xs text-[#FAF6EE]/60">Belum diserahkan.</p>
                )}
              </div>

              {/* Teacher Assessment Form */}
              <form
                onSubmit={handleSubmitFeedback}
                className="rounded-xl border border-[#D4AF37]/30 bg-[#162038] p-4 space-y-3"
              >
                <div className="flex items-center gap-2 text-sm font-semibold text-[#D4AF37]">
                  <MessageSquare className="w-4 h-4" />
                  <span>Penilaian & Maklum Balas Guru</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-1">
                    <label className="block text-xs text-[#C8B6E2] mb-1">Tahap Penguasaan</label>
                    <select
                      value={ratingLabel}
                      onChange={(e) =>
                        setRatingLabel(
                          e.target.value as 'Sedang Dibimbing' | 'Memuaskan' | 'Baik' | 'Cemerlang',
                        )
                      }
                      className="w-full rounded-lg border border-[#FAF6EE]/20 bg-[#1B2948] px-3 py-2 text-xs text-[#FAF6EE]"
                    >
                      <option value="Sedang Dibimbing">Sedang Dibimbing</option>
                      <option value="Memuaskan">Memuaskan</option>
                      <option value="Baik">Baik</option>
                      <option value="Cemerlang">Cemerlang</option>
                    </select>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs text-[#C8B6E2] mb-1">Ulasan Membina</label>
                    <textarea
                      rows={2}
                      required
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Berikan pujian terhadap usaha serta cadangan penambahbaikan penceritaan murid..."
                      className="w-full rounded-lg border border-[#FAF6EE]/20 bg-[#1B2948] px-3 py-2 text-xs text-[#FAF6EE]"
                    />
                  </div>
                </div>
                {saveMsg && <p className="text-xs text-[#7FA88C]">{saveMsg}</p>}
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#162038] text-xs font-semibold hover:bg-[#E2C258]"
                  >
                    Simpan Maklum Balas Guru
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="rounded-xl border border-[#FAF6EE]/15 bg-[#1B2948] p-8 text-center text-sm text-[#FAF6EE]/60">
              Pilih seorang murid daripada senarai untuk menyemak tugasan.
            </div>
          )}
        </section>
      </main>
    </div>
  );
};

interface AdminPortalProps {
  user: AuthUser;
  token: string;
  onEnterWorld3D: () => void;
  onLogout: () => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  user,
  token,
  onEnterWorld3D,
  onLogout,
}) => {
  const [users, setUsers] = useState<AuthUser[]>([]);
  const [config, setConfig] = useState<AdminContentConfig | null>(null);
  const [newUsername, setNewUsername] = useState('');
  const [newFullName, setNewFullName] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('student');
  const [newClass, setNewClass] = useState('5 Bestari');
  const [statusMsg, setStatusMsg] = useState('');

  const loadAdminData = async () => {
    const res = await fetch('/api/admin/users', {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) {
      const data = (await res.json()) as { users: AuthUser[]; config: AdminContentConfig };
      setUsers(data.users);
      setConfig(data.config);
    }
  };

  useEffect(() => {
    void loadAdminData();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg('');
    const res = await fetch('/api/admin/users', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        username: newUsername,
        fullName: newFullName,
        password: newPassword,
        role: newRole,
        className: newClass,
      }),
    });
    const d = (await res.json()) as { error?: string };
    if (res.ok) {
      setNewUsername('');
      setNewFullName('');
      setNewPassword('');
      setStatusMsg('Akaun pengguna baharu berjaya dicipta.');
      await loadAdminData();
    } else {
      setStatusMsg(d.error || 'Gagal mencipta akaun.');
    }
  };

  const handleRoleChange = async (userId: string, role: UserRole) => {
    await fetch(`/api/admin/users/${userId}/role`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ role }),
    });
    await loadAdminData();
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!config) return;
    const res = await fetch('/api/admin/config', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(config),
    });
    if (res.ok) {
      setStatusMsg('Tetapan kandungan pembelajaran berjaya dikemas kini.');
    }
  };

  return (
    <div className="min-h-screen w-full overflow-y-auto bg-[#162038] text-[#FAF6EE]">
      <header className="border-b border-[#D4AF37]/25 bg-[#1B2948] px-6 py-4 flex items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-6 h-6 text-[#D4AF37]" />
          <div>
            <h1 className="font-display text-lg font-semibold text-[#FAF6EE]">
              Portal Pentadbir · Kingdom of Stories
            </h1>
            <p className="text-xs text-[#C8B6E2]">Pengurusan Akaun, Peranan & Kandungan Pembelajaran</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onEnterWorld3D}
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#E5C35A] bg-[#233256] text-xs font-semibold text-[#E5C35A] hover:bg-[#2C3F6C]"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Masuk Dunia 3D</span>
          </button>
          <button
            type="button"
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#FAF6EE]/20 bg-[#162038] text-xs font-semibold hover:bg-[#233256]"
          >
            <LogOut className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Log Keluar</span>
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6 space-y-6">
        <section className="rounded-2xl border border-[#D4AF37]/40 bg-gradient-to-r from-[#172347] via-[#1F2C58] to-[#172347] p-5 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#E5C35A]">
              <Sparkles className="w-4 h-4" />
              <span>Dunia 3D Kingdom of Stories · Kesemua 5 Misi Terbuka</span>
            </div>
            <h2 className="font-display text-lg font-bold text-[#FAF6EE]">
              Pratonton Persekitaran &amp; Aliran 5 Misi
            </h2>
            <p className="text-xs sm:text-sm text-[#EFE6D5]/85">
              Uji dan nilai kesemua lima lokasi kerajaan secara bebas pada bila-bila masa tanpa menjejaskan rekod pembelajaran murid.
            </p>
          </div>
          <button
            type="button"
            onClick={onEnterWorld3D}
            className="px-5 py-2.5 rounded-xl bg-[#D4AF37] text-[#162038] text-xs font-bold hover:bg-[#E5C35A] transition-colors whitespace-nowrap shrink-0"
          >
            Masuk Dunia 3D (5 Misi Terbuka)
          </button>
        </section>

        {statusMsg && (
          <div className="rounded-xl border border-[#D4AF37]/45 bg-[#233256] p-3.5 text-xs text-[#FAF6EE]">
            {statusMsg}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Users & RBAC Table */}
          <section className="lg:col-span-7 rounded-2xl border border-[#FAF6EE]/15 bg-[#1B2948] p-5 space-y-4">
            <h2 className="text-sm font-semibold text-[#D4AF37] flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span>Pengurusan Akaun & Peranan ({users.length})</span>
            </h2>
            <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
              {users.map((u) => (
                <div
                  key={u.id}
                  className="rounded-xl bg-[#162038] border border-[#FAF6EE]/10 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <div className="font-semibold text-[#FAF6EE]">{u.fullName}</div>
                    <div className="text-[#C8B6E2]">
                      @{u.username} {u.className ? `· ${u.className}` : ''}
                    </div>
                  </div>
                  <select
                    value={u.role}
                    disabled={u.id === user.id}
                    onChange={(e) => void handleRoleChange(u.id, e.target.value as UserRole)}
                    className="rounded-lg border border-[#FAF6EE]/20 bg-[#1B2948] px-2.5 py-1.5 text-xs text-[#FAF6EE]"
                  >
                    <option value="student">Pelajar</option>
                    <option value="teacher">Guru</option>
                    <option value="admin">Pentadbir</option>
                  </select>
                </div>
              ))}
            </div>
          </section>

          {/* Create New Account */}
          <section className="lg:col-span-5 rounded-2xl border border-[#FAF6EE]/15 bg-[#1B2948] p-5 space-y-4">
            <h2 className="text-sm font-semibold text-[#8FBCE0] flex items-center gap-2">
              <UserPlus className="w-4 h-4" />
              <span>Daftar Pengguna Baharu</span>
            </h2>
            <form onSubmit={handleCreateUser} className="space-y-3 text-xs">
              <input
                type="text"
                required
                value={newFullName}
                onChange={(e) => setNewFullName(e.target.value)}
                placeholder="Nama Penuh"
                className="w-full rounded-lg border border-[#FAF6EE]/20 bg-[#162038] px-3 py-2 text-[#FAF6EE]"
              />
              <input
                type="text"
                required
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder="Nama Pengguna"
                className="w-full rounded-lg border border-[#FAF6EE]/20 bg-[#162038] px-3 py-2 text-[#FAF6EE]"
              />
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Kata Laluan"
                className="w-full rounded-lg border border-[#FAF6EE]/20 bg-[#162038] px-3 py-2 text-[#FAF6EE]"
              />
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as UserRole)}
                  className="rounded-lg border border-[#FAF6EE]/20 bg-[#162038] px-3 py-2 text-[#FAF6EE]"
                >
                  <option value="student">Pelajar</option>
                  <option value="teacher">Guru</option>
                  <option value="admin">Pentadbir</option>
                </select>
                <input
                  type="text"
                  value={newClass}
                  onChange={(e) => setNewClass(e.target.value)}
                  placeholder="Kelas"
                  className="rounded-lg border border-[#FAF6EE]/20 bg-[#162038] px-3 py-2 text-[#FAF6EE]"
                />
              </div>
              <button
                type="submit"
                className="w-full py-2.5 rounded-lg bg-[#D4AF37] text-[#162038] font-semibold hover:bg-[#E2C258]"
              >
                Cipta Akaun
              </button>
            </form>
          </section>
        </div>

        {/* Learning Content & Game Settings */}
        {config && (
          <form
            onSubmit={handleSaveConfig}
            className="rounded-2xl border border-[#D4AF37]/30 bg-[#1B2948] p-6 space-y-4"
          >
            <h2 className="text-sm font-semibold text-[#D4AF37]">
              Tetapan Kandungan & Misi Tugasan
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-[#C8B6E2] mb-1">Tajuk Projek Penceritaan</label>
                <input
                  type="text"
                  value={config.storyTitle}
                  onChange={(e) => setConfig({ ...config, storyTitle: e.target.value })}
                  className="w-full rounded-lg border border-[#FAF6EE]/20 bg-[#162038] px-3 py-2 text-[#FAF6EE]"
                />
              </div>
              <div>
                <label className="block text-[#C8B6E2] mb-1">Pengumuman Kerajaan</label>
                <input
                  type="text"
                  value={config.announcement}
                  onChange={(e) => setConfig({ ...config, announcement: e.target.value })}
                  className="w-full rounded-lg border border-[#FAF6EE]/20 bg-[#162038] px-3 py-2 text-[#FAF6EE]"
                />
              </div>
            </div>
            <div className="flex flex-wrap gap-4 text-xs">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.enableCollaborativeMode}
                  onChange={(e) =>
                    setConfig({ ...config, enableCollaborativeMode: e.target.checked })
                  }
                  className="accent-[#D4AF37]"
                />
                <span>Benarkan Mod Pembelajaran Kolaboratif</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.enableAdaptiveHints}
                  onChange={(e) =>
                    setConfig({ ...config, enableAdaptiveHints: e.target.checked })
                  }
                  className="accent-[#D4AF37]"
                />
                <span>Aktifkan Petunjuk Pembelajaran Adaptif</span>
              </label>
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-[#D4AF37] text-[#162038] text-xs font-semibold hover:bg-[#E2C258]"
              >
                Simpan Tetapan Sistem
              </button>
            </div>
          </form>
        )}
      </main>
    </div>
  );
};
