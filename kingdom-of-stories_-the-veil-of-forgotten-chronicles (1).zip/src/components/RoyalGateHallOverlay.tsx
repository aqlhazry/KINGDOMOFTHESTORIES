import React from 'react';
import { ArrowRight, CheckCircle2, Sparkles } from 'lucide-react';
import type { MissionId, PlayerProgress } from '../types/game';

export interface GateMissionCardItem {
  number: 1 | 2 | 3 | 4 | 5;
  id: MissionId;
  locationName: string;
  subtitle: string;
  accentColor: string;
}

export const GATE_HALL_MISSIONS: GateMissionCardItem[] = [
  {
    number: 1,
    id: 'silent_chronicle',
    locationName: 'Pustaka Agung Hikayat Diraja',
    subtitle: 'Kemahiran Mendengar',
    accentColor: '#38BDF8',
  },
  {
    number: 2,
    id: 'shattered_timeline',
    locationName: 'Rimba Cahaya Mahkota',
    subtitle: 'Kronologi Hikayat',
    accentColor: '#34D399',
  },
  {
    number: 3,
    id: 'story_architect',
    locationName: 'Balai Cipta Mahkota',
    subtitle: 'Arkitek Kisah & Skrip',
    accentColor: '#A78BFA',
  },
  {
    number: 4,
    id: 'royal_voice_trial',
    locationName: 'Balai Gema Diraja',
    subtitle: 'Ujian Suara Diraja',
    accentColor: '#F472B6',
  },
  {
    number: 5,
    id: 'final_chronicle',
    locationName: 'Balairung Gemilang Diraja',
    subtitle: 'Pentas Persembahan',
    accentColor: '#FBBF24',
  },
];

interface RoyalGateHallOverlayProps {
  progress: PlayerProgress;
  dockCollapsed: boolean;
  disabled?: boolean;
  onSelectMission: (missionNumber: 1 | 2 | 3 | 4 | 5) => void;
}

export const RoyalGateHallOverlay: React.FC<RoyalGateHallOverlayProps> = ({
  progress,
  dockCollapsed,
  disabled = false,
  onSelectMission,
}) => {
  return (
    <div
      className={`pointer-events-none fixed inset-x-0 z-20 flex justify-center px-3 sm:px-5 transition-all duration-200 ${
        dockCollapsed ? 'bottom-12' : 'bottom-[5.25rem]'
      }`}
    >
      <div className="pointer-events-auto w-full max-w-6xl rounded-2xl border border-[#D4AF37]/50 bg-[#0F1832]/94 px-3.5 py-3 shadow-[0_18px_48px_rgba(6,10,26,0.75)]">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-2.5 border-b border-[#FAF6EE]/10">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#E5C97B]">
            <Sparkles className="w-3.5 h-3.5 shrink-0" />
            <span>Dewan Gerbang Diraja — Klik Mana-Mana Misi untuk Terus Masuk ke Portal</span>
          </div>
          <div className="text-[11px] font-medium text-[#C8B6E2]">
            Akses Terbuka: {progress.completedMissions.length}/5 Misi Selesai
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {GATE_HALL_MISSIONS.map((item) => {
            const isDone = progress.completedMissions.includes(item.id);
            return (
              <button
                key={item.id}
                type="button"
                disabled={disabled}
                onClick={() => onSelectMission(item.number)}
                className="group relative flex flex-col justify-between text-left rounded-xl border border-[#FAF6EE]/15 bg-[#162246] hover:bg-[#1E2F5E] hover:border-[#E5C97B]/75 px-3 py-2.5 transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-[#E5C97B] disabled:opacity-50"
              >
                <span
                  aria-hidden="true"
                  className="absolute inset-x-3 top-0 h-0.5 rounded-b"
                  style={{ backgroundColor: item.accentColor }}
                />
                <div className="flex items-center justify-between gap-1.5 w-full">
                  <span
                    className="font-display text-xs font-bold tracking-wide"
                    style={{ color: item.accentColor }}
                  >
                    MISI {item.number}
                  </span>
                  {isDone ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-[#6EE7B7]">
                      <CheckCircle2 className="w-3 h-3 shrink-0" />
                      <span>Selesai</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-[#E5C97B] group-hover:translate-x-0.5 transition-transform">
                      <span>Masuk</span>
                      <ArrowRight className="w-3 h-3 shrink-0" />
                    </span>
                  )}
                </div>

                <div className="mt-1 text-xs font-semibold text-[#FAF6EE] leading-snug line-clamp-2">
                  {item.locationName}
                </div>
                <div className="mt-0.5 text-[10px] text-[#C8B6E2]/85 truncate">
                  {item.subtitle}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
