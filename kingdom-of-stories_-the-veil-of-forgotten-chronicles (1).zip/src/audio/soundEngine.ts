import type { AudioSettings, LocationId } from '../types/game';
import {
  normalizeMalayForSpeech,
  type PublicVoiceGuideId,
  VOICE_PROFILES,
  type VoiceRole,
  type VoiceStyleHint,
} from './voiceProfiles';

interface ThemeChord {
  bass: number;
  pad: number[];
  arp: number[];
}

const LOCATION_THEMES: Record<LocationId, ThemeChord[]> = {
  citadel: [
    // Majestic Royal Fanfare & Warm Strings (C Maj9 -> G/B -> Am7 -> F Maj7)
    { bass: 130.81, pad: [261.63, 329.63, 392.0, 587.33], arp: [523.25, 659.25, 783.99, 1046.5] },
    { bass: 123.47, pad: [246.94, 293.66, 392.0, 493.88], arp: [493.88, 587.33, 783.99, 987.77] },
    { bass: 110.0, pad: [220.0, 261.63, 329.63, 392.0], arp: [440.0, 523.25, 659.25, 783.99] },
    { bass: 87.31, pad: [174.61, 220.0, 261.63, 329.63], arp: [349.23, 440.0, 523.25, 659.25] },
  ],
  gate_hall: [
    // Radiant Royal Portal Sanctuary (D Maj9 -> A/C# -> G Maj7 -> A7sus4)
    { bass: 146.83, pad: [293.66, 369.99, 440.0, 659.25], arp: [587.33, 739.99, 880.0, 1174.66] },
    { bass: 138.59, pad: [277.18, 329.63, 440.0, 554.37], arp: [554.37, 659.25, 880.0, 1108.73] },
    { bass: 98.0, pad: [196.0, 246.94, 293.66, 369.99], arp: [392.0, 493.88, 587.33, 739.99] },
    { bass: 110.0, pad: [220.0, 293.66, 329.63, 440.0], arp: [440.0, 587.33, 659.25, 880.0] },
  ],
  library: [
    // Luminous Lydian Archive (D Maj7 -> E/D -> Bm7 -> A Maj7)
    { bass: 146.83, pad: [293.66, 369.99, 440.0, 554.37], arp: [587.33, 739.99, 880.0, 1108.73] },
    { bass: 146.83, pad: [329.63, 415.3, 493.88, 659.25], arp: [659.25, 830.61, 987.77, 1174.66] },
    { bass: 123.47, pad: [246.94, 293.66, 369.99, 440.0], arp: [493.88, 587.33, 739.99, 880.0] },
    { bass: 110.0, pad: [220.0, 277.18, 329.63, 415.3], arp: [440.0, 554.37, 659.25, 830.61] },
  ],
  woods: [
    // Gentle Sunlit Enchanted Forest (Em9 -> C Maj7 -> G Maj7 -> Dsus4)
    { bass: 164.81, pad: [246.94, 293.66, 369.99, 493.88], arp: [493.88, 587.33, 739.99, 987.77] },
    { bass: 130.81, pad: [261.63, 329.63, 392.0, 493.88], arp: [523.25, 659.25, 783.99, 987.77] },
    { bass: 98.0, pad: [196.0, 246.94, 293.66, 369.99], arp: [392.0, 493.88, 587.33, 739.99] },
    { bass: 146.83, pad: [220.0, 293.66, 392.0, 440.0], arp: [440.0, 587.33, 783.99, 880.0] },
  ],
  atelier: [
    // Creative Arcane Harp & Choir (Eb Maj7 -> Cm9 -> Ab Maj7 -> Bb6)
    { bass: 155.56, pad: [311.13, 392.0, 466.16, 587.33], arp: [622.25, 783.99, 932.33, 1174.66] },
    { bass: 130.81, pad: [261.63, 311.13, 392.0, 587.33], arp: [523.25, 622.25, 783.99, 1046.5] },
    { bass: 103.83, pad: [207.65, 261.63, 311.13, 392.0], arp: [415.3, 523.25, 622.25, 783.99] },
    { bass: 116.54, pad: [233.08, 293.66, 349.23, 392.0], arp: [466.16, 587.33, 698.46, 783.99] },
  ],
  theatre: [
    // Grand Palace Opera & Symphonic Coronation (D Maj9 -> A/C# -> Bm7 -> G Maj7 -> A7sus4)
    { bass: 146.83, pad: [293.66, 369.99, 440.0, 587.33, 659.25], arp: [587.33, 739.99, 880.0, 1174.66, 1318.51] },
    { bass: 138.59, pad: [277.18, 329.63, 440.0, 554.37], arp: [554.37, 659.25, 880.0, 1108.73, 1318.51] },
    { bass: 123.47, pad: [246.94, 293.66, 369.99, 493.88], arp: [493.88, 587.33, 739.99, 987.77, 1174.66] },
    { bass: 98.0, pad: [196.0, 246.94, 293.66, 392.0, 493.88], arp: [392.0, 493.88, 587.33, 783.99, 987.77] },
    { bass: 110.0, pad: [220.0, 293.66, 329.63, 440.0], arp: [440.0, 587.33, 659.25, 880.0, 1174.66] },
  ],
};

const LANDING_THEME: ThemeChord[] = [
  // Serene Royal Fantasy Prelude (F Maj9 -> G6 -> Em7 -> Am9)
  { bass: 87.31, pad: [174.61, 220.0, 261.63, 392.0], arp: [349.23, 440.0, 523.25, 659.25, 783.99] },
  { bass: 98.0, pad: [196.0, 246.94, 293.66, 392.0], arp: [392.0, 493.88, 587.33, 659.25, 783.99] },
  { bass: 164.81, pad: [164.81, 246.94, 293.66, 392.0], arp: [392.0, 493.88, 587.33, 739.99, 987.77] },
  { bass: 110.0, pad: [220.0, 261.63, 329.63, 493.88], arp: [440.0, 523.25, 659.25, 783.99, 987.77] },
];

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicInterval: number | null = null;
  private isPlayingMusic = false;
  private isDucked = false;
  private isLandingAmbience = false;
  private lastHoverSfxAt = 0;
  private currentLocation: LocationId = 'citadel';
  private activeAudioEl: HTMLAudioElement | null = null;
  private authToken: string =
    typeof window !== 'undefined' ? window.localStorage?.getItem('kos_token') || '' : '';
  private narrationSeq = 0;
  private ttsAbortController: AbortController | null = null;
  private clientTtsCache = new Map<string, string>();
  private speaking = false;
  private narrationListeners = new Set<(speaking: boolean) => void>();
  private settings: AudioSettings = {
    masterVolume: 0.75,
    musicVolume: 0.45,
    sfxVolume: 0.75,
    narrationVolume: 0.9,
    musicMuted: false,
    sfxMuted: false,
    showSubtitles: true,
  };

  setAuthToken(token: string): void {
    this.authToken = token;
  }

  isNarrating(): boolean {
    return this.speaking;
  }

  subscribeNarration(listener: (speaking: boolean) => void): () => void {
    this.narrationListeners.add(listener);
    return () => {
      this.narrationListeners.delete(listener);
    };
  }

  private setSpeakingState(next: boolean): void {
    if (this.speaking === next) return;
    this.speaking = next;
    this.narrationListeners.forEach((cb) => cb(next));
  }

  init(): void {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        void this.ctx.resume();
      }
      return;
    }
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    this.ctx = new AudioCtx();
    this.masterGain = this.ctx.createGain();
    this.musicGain = this.ctx.createGain();
    this.sfxGain = this.ctx.createGain();

    this.musicGain.connect(this.masterGain);
    this.sfxGain.connect(this.masterGain);
    this.masterGain.connect(this.ctx.destination);

    this.applyVolumes();
  }

  hasUserActivatedAudio(): boolean {
    return Boolean(this.ctx && this.ctx.state === 'running');
  }

  updateSettings(next: AudioSettings): void {
    this.settings = { ...next, sfxMuted: next.sfxMuted ?? this.settings.sfxMuted };
    this.applyVolumes();
    if (this.activeAudioEl) {
      this.activeAudioEl.volume = this.settings.narrationVolume * this.settings.masterVolume;
    }
  }

  getSettings(): AudioSettings {
    return { ...this.settings };
  }

  setMusicMuted(muted: boolean): void {
    this.settings = { ...this.settings, musicMuted: muted };
    this.applyVolumes();
    if (!muted) {
      this.startMusic();
    }
  }

  setSfxMuted(muted: boolean): void {
    this.settings = { ...this.settings, sfxMuted: muted };
    this.applyVolumes();
  }

  getMusicMuted(): boolean {
    return this.settings.musicMuted;
  }

  getSfxMuted(): boolean {
    return Boolean(this.settings.sfxMuted);
  }

  isMusicActive(): boolean {
    return this.isPlayingMusic && !this.settings.musicMuted && this.hasUserActivatedAudio();
  }

  setLandingAmbience(enabled: boolean): void {
    this.isLandingAmbience = enabled;
  }

  private applyVolumes(): void {
    if (!this.ctx || !this.masterGain || !this.musicGain || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    this.masterGain.gain.setTargetAtTime(this.settings.masterVolume, now, 0.08);
    const duckFactor = this.isDucked ? 0.24 : 1.0;
    const targetMusic = this.settings.musicMuted ? 0 : this.settings.musicVolume * duckFactor * 0.42;
    this.musicGain.gain.setTargetAtTime(targetMusic, now, 0.15);
    const targetSfx = this.settings.sfxMuted ? 0 : this.settings.sfxVolume * 0.55;
    this.sfxGain.gain.setTargetAtTime(targetSfx, now, 0.05);
  }

  duckMusic(duck: boolean): void {
    this.isDucked = duck;
    this.applyVolumes();
  }

  setLocationAmbience(location: LocationId): void {
    this.isLandingAmbience = false;
    this.currentLocation = location;
  }

  private playWarmStringPad(freq: number, startTime: number, duration: number, peak: number): void {
    if (!this.ctx || !this.musicGain) return;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(920, startTime);
    filter.Q.value = 0.7;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(peak, startTime + 0.65);
    gain.gain.setValueAtTime(peak * 0.88, startTime + duration - 0.75);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    [-3, 3].forEach((detune) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, startTime);
      osc.detune.setValueAtTime(detune, startTime);
      osc.connect(filter);
      osc.start(startTime);
      osc.stop(startTime + duration + 0.05);
    });

    filter.connect(gain);
    gain.connect(this.musicGain);
  }

  private playHarpOrBell(freq: number, startTime: number, isBell: boolean, peak: number): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const overtone = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = isBell ? 'sine' : 'triangle';
    overtone.type = 'sine';
    osc.frequency.setValueAtTime(freq, startTime);
    overtone.frequency.setValueAtTime(freq * (isBell ? 3.0 : 2.0), startTime);

    const overGain = this.ctx.createGain();
    overGain.gain.setValueAtTime(isBell ? 0.28 : 0.16, startTime);

    const decay = isBell ? 1.85 : 1.35;
    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(peak, startTime + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + decay);

    osc.connect(gain);
    overtone.connect(overGain);
    overGain.connect(gain);
    gain.connect(this.musicGain);

    osc.start(startTime);
    overtone.start(startTime);
    osc.stop(startTime + decay + 0.05);
    overtone.stop(startTime + decay + 0.05);
  }

  private playBrassOrTimpani(freq: number, startTime: number, isTimpani: boolean): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    if (isTimpani) {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq * 1.12, startTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.78, startTime + 0.35);
      gain.gain.setValueAtTime(0.0001, startTime);
      gain.gain.linearRampToValueAtTime(0.09, startTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.65);
      osc.connect(gain);
      gain.connect(this.musicGain);
      osc.start(startTime);
      osc.stop(startTime + 0.7);
    } else {
      // Soft French Horn swell
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, startTime);
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(520, startTime);
      filter.frequency.linearRampToValueAtTime(980, startTime + 0.6);
      gain.gain.setValueAtTime(0.0001, startTime);
      gain.gain.linearRampToValueAtTime(0.048, startTime + 0.45);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 2.3);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.musicGain);
      osc.start(startTime);
      osc.stop(startTime + 2.4);
    }
  }

  startMusic(): void {
    this.init();
    if (!this.ctx || this.isPlayingMusic) return;
    this.isPlayingMusic = true;

    let barIndex = 0;
    const playOrchestralBar = () => {
      if (!this.ctx || !this.musicGain || !this.isPlayingMusic || this.settings.musicMuted) return;
      if (this.ctx.state === 'suspended') return;

      const prog = this.isLandingAmbience
        ? LANDING_THEME
        : LOCATION_THEMES[this.currentLocation] || LOCATION_THEMES.citadel;
      const chord = prog[barIndex % prog.length];
      const now = this.ctx.currentTime;

      // 1. Warm String Ensemble Chord Pad
      chord.pad.slice(0, 3).forEach((freq) => {
        this.playWarmStringPad(freq, now, 3.1, this.isLandingAmbience ? 0.032 : 0.036);
      });

      // 2. Royal Horn / Choir Accent on Citadel & Balairung Gemilang Diraja, soft Timpani pulse
      if (!this.isLandingAmbience && (this.currentLocation === 'citadel' || this.currentLocation === 'theatre')) {
        this.playBrassOrTimpani(chord.bass * 2, now + 0.1, false);
        if (this.currentLocation === 'theatre') {
          this.playBrassOrTimpani(chord.bass * 3, now + 1.15, false);
        }
        if (barIndex % 2 === 0 || this.currentLocation === 'theatre') {
          this.playBrassOrTimpani(chord.bass, now, true);
        }
      }

      // 3. Harp Arpeggio + Celesta/Bell Sparkle
      const isBell =
        this.isLandingAmbience ||
        this.currentLocation === 'library' ||
        this.currentLocation === 'woods' ||
        this.currentLocation === 'theatre';
      chord.arp.forEach((freq, idx) => {
        this.playHarpOrBell(freq, now + idx * (this.isLandingAmbience ? 0.46 : 0.42), isBell && idx % 2 === 1, 0.068);
      });

      barIndex++;
    };

    playOrchestralBar();
    this.musicInterval = window.setInterval(playOrchestralBar, 2900);
  }

  stopMusic(): void {
    this.isPlayingMusic = false;
    if (this.musicInterval !== null) {
      window.clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
  }

  playPortalSound(): void {
    this.init();
    if (!this.ctx || !this.sfxGain || this.settings.sfxMuted) return;
    const now = this.ctx.currentTime;
    [329.63, 440, 523.25, 659.25, 783.99].forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.07);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.25, now + i * 0.07 + 0.45);
      g.gain.setValueAtTime(0.001, now + i * 0.07);
      g.gain.linearRampToValueAtTime(0.18, now + i * 0.07 + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.07 + 0.6);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(now + i * 0.07);
      osc.stop(now + i * 0.07 + 0.65);
    });
  }

  playPortalHoverSound(role: 'student' | 'teacher' | 'admin' = 'student'): void {
    // Never auto-create AudioContext on passive pointer hover before explicit user activation
    if (!this.ctx || this.ctx.state !== 'running' || !this.sfxGain || this.settings.sfxMuted) return;
    const perfNow = performance.now();
    if (perfNow - this.lastHoverSfxAt < 160) return;
    this.lastHoverSfxAt = perfNow;

    const now = this.ctx.currentTime;
    const notes =
      role === 'student'
        ? [523.25, 783.99]
        : role === 'teacher'
          ? [587.33, 880.0]
          : [493.88, 739.99];
    notes.forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.055);
      g.gain.setValueAtTime(0.001, now + i * 0.055);
      g.gain.linearRampToValueAtTime(0.09, now + i * 0.055 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.055 + 0.36);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(now + i * 0.055);
      osc.stop(now + i * 0.055 + 0.4);
    });
  }

  playUiHoverSound(): void {
    if (!this.ctx || this.ctx.state !== 'running' || !this.sfxGain || this.settings.sfxMuted) return;
    const perfNow = performance.now();
    if (perfNow - this.lastHoverSfxAt < 120) return;
    this.lastHoverSfxAt = perfNow;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(698.46, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.08);
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(0.055, now + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.14);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.16);
  }

  playUiClickSound(): void {
    this.init();
    if (!this.ctx || !this.sfxGain || this.settings.sfxMuted) return;
    const now = this.ctx.currentTime;
    [659.25, 987.77].forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.04);
      g.gain.setValueAtTime(0.001, now + i * 0.04);
      g.gain.linearRampToValueAtTime(0.11, now + i * 0.04 + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.04 + 0.19);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(now + i * 0.04);
      osc.stop(now + i * 0.04 + 0.22);
    });
  }

  playPageTurnSound(): void {
    this.init();
    if (!this.ctx || !this.sfxGain || this.settings.sfxMuted) return;
    const now = this.ctx.currentTime;
    const bufferSize = Math.floor(this.ctx.sampleRate * 0.24);
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.sin((i / bufferSize) * Math.PI);
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = noiseBuffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1400, now);
    filter.frequency.exponentialRampToValueAtTime(2600, now + 0.18);
    filter.Q.value = 1.4;

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(0.14, now + 0.04);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.24);

    noise.connect(filter);
    filter.connect(g);
    g.connect(this.sfxGain);
    noise.start(now);
    noise.stop(now + 0.25);
  }

  playCrystalChimeSound(): void {
    this.init();
    if (!this.ctx || !this.sfxGain || this.settings.sfxMuted) return;
    const now = this.ctx.currentTime;
    [587.33, 880.0, 1174.66].forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + i * 0.065);
      g.gain.setValueAtTime(0.001, now + i * 0.065);
      g.gain.linearRampToValueAtTime(0.11, now + i * 0.065 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.065 + 0.55);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(now + i * 0.065);
      osc.stop(now + i * 0.065 + 0.6);
    });
  }

  playCollectSound(): void {
    this.init();
    if (!this.ctx || !this.sfxGain || this.settings.sfxMuted) return;
    const now = this.ctx.currentTime;
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.06);
      g.gain.setValueAtTime(0.001, now + i * 0.06);
      g.gain.linearRampToValueAtTime(0.22, now + i * 0.06 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.06 + 0.32);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(now + i * 0.06);
      osc.stop(now + i * 0.06 + 0.35);
    });
  }

  playMissionComplete(): void {
    this.init();
    if (!this.ctx || !this.sfxGain || this.settings.sfxMuted) return;
    const now = this.ctx.currentTime;
    const chord = [261.63, 329.63, 392.0, 523.25, 659.25];
    chord.forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.09);
      g.gain.setValueAtTime(0.001, now + i * 0.09);
      g.gain.linearRampToValueAtTime(0.24, now + i * 0.09 + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.09 + 0.9);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(now + i * 0.09);
      osc.stop(now + i * 0.09 + 0.95);
    });
  }

  playInteractBeep(): void {
    this.init();
    if (!this.ctx || !this.sfxGain || this.settings.sfxMuted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.linearRampToValueAtTime(587.33, now + 0.1);
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(0.15, now + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.18);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.2);
  }

  private async loadSpeechVoices(): Promise<SpeechSynthesisVoice[]> {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return [];
    const current = window.speechSynthesis.getVoices();
    if (current.length > 0) return current;
    return await new Promise<SpeechSynthesisVoice[]>((resolve) => {
      let resolved = false;
      const done = () => {
        if (resolved) return;
        resolved = true;
        resolve(window.speechSynthesis.getVoices());
      };
      window.speechSynthesis.addEventListener('voiceschanged', done, { once: true });
      window.setTimeout(done, 150);
    });
  }

  private pickMalaysianVoice(
    voices: SpeechSynthesisVoice[],
    gender: 'male' | 'female',
  ): SpeechSynthesisVoice | undefined {
    const isIndonesian = (v: SpeechSynthesisVoice) => {
      const lang = v.lang.toLowerCase().replace('_', '-');
      const name = v.name.toLowerCase();
      return lang.startsWith('id') || name.includes('indonesia') || name.includes('damayanti');
    };
    const msMyVoices = voices.filter((v) => {
      const lang = v.lang.toLowerCase().replace('_', '-');
      return !isIndonesian(v) && (lang === 'ms-my' || lang.startsWith('ms-') || lang === 'ms');
    });
    const malayNameVoices =
      msMyVoices.length > 0
        ? msMyVoices
        : voices.filter(
            (v) =>
              !isIndonesian(v) &&
              (v.name.toLowerCase().includes('malay') || v.name.toLowerCase().includes('melayu')),
          );

    if (malayNameVoices.length === 0) return undefined;

    const maleHints = ['osman', 'male', 'lelaki', 'ahmad', 'arif'];
    const femaleHints = ['yasmin', 'amira', 'female', 'perempuan', 'seri', 'siti'];
    const hints = gender === 'male' ? maleHints : femaleHints;

    return (
      malayNameVoices.find((v) => hints.some((h) => v.name.toLowerCase().includes(h))) ||
      malayNameVoices[0]
    );
  }

  stopNarration(): void {
    this.narrationSeq++;
    if (this.ttsAbortController) {
      this.ttsAbortController.abort();
      this.ttsAbortController = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (this.activeAudioEl) {
      this.activeAudioEl.onended = null;
      this.activeAudioEl.onerror = null;
      this.activeAudioEl.pause();
      this.activeAudioEl = null;
    }
    this.setSpeakingState(false);
    this.duckMusic(false);
  }

  private playWavBase64(
    base64Audio: string,
    seq: number,
    onEnd?: () => void,
  ): Promise<boolean> {
    return new Promise((resolve) => {
      if (seq !== this.narrationSeq) {
        resolve(false);
        return;
      }
      const audio = new Audio(`data:audio/wav;base64,${base64Audio}`);
      audio.volume = Math.min(1, Math.max(0, this.settings.narrationVolume * this.settings.masterVolume));
      this.activeAudioEl = audio;
      this.setSpeakingState(true);

      audio.onended = () => {
        if (this.activeAudioEl === audio) {
          this.activeAudioEl = null;
        }
        if (seq === this.narrationSeq) {
          this.setSpeakingState(false);
          this.duckMusic(false);
          onEnd?.();
        }
        resolve(true);
      };
      audio.onerror = () => {
        if (this.activeAudioEl === audio) {
          this.activeAudioEl = null;
        }
        resolve(false);
      };

      void audio.play().catch(() => {
        if (this.activeAudioEl === audio) {
          this.activeAudioEl = null;
        }
        resolve(false);
      });
    });
  }

  async speakMalay(
    text: string,
    options?: {
      voiceRole?: VoiceRole;
      styleHint?: VoiceStyleHint;
      pitch?: number;
      rate?: number;
      onEnd?: () => void;
      tryServerTts?: boolean;
      publicGuideId?: PublicVoiceGuideId;
    },
  ): Promise<void> {
    this.init();
    this.stopNarration();
    const seq = this.narrationSeq;

    const voiceRole: VoiceRole = options?.voiceRole ?? 'narrator';
    const styleHint: VoiceStyleHint = options?.styleHint ?? 'story';
    const profile = VOICE_PROFILES[voiceRole] || VOICE_PROFILES.narrator;
    const spokenText = normalizeMalayForSpeech(text);
    if (!spokenText) {
      options?.onEnd?.();
      return;
    }

    this.duckMusic(true);
    this.setSpeakingState(true);

    const cacheKey = options?.publicGuideId
      ? `guide:${options.publicGuideId}`
      : `${voiceRole}:${styleHint}:${spokenText}`;

    // 1. Check client WAV cache first for instant playback
    const cachedWav = this.clientTtsCache.get(cacheKey);
    if (cachedWav) {
      const played = await this.playWavBase64(cachedWav, seq, options?.onEnd);
      if (played || seq !== this.narrationSeq) return;
    }

    // 2. Try server-side Gemini AI TTS by default (requires authToken unless publicGuideId)
    const shouldTryServer = options?.tryServerTts !== false;
    const canFetchGuide = Boolean(options?.publicGuideId);
    const activeToken =
      this.authToken ||
      (typeof window !== 'undefined' ? window.localStorage?.getItem('kos_token') || '' : '');

    if (shouldTryServer && (canFetchGuide || activeToken)) {
      const controller = new AbortController();
      this.ttsAbortController = controller;
      try {
        const res = await fetch(canFetchGuide ? '/api/tts/guide' : '/api/tts', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(activeToken && !canFetchGuide ? { Authorization: `Bearer ${activeToken}` } : {}),
          },
          body: JSON.stringify(
            canFetchGuide
              ? { guideId: options!.publicGuideId }
              : { text: spokenText, voiceRole, styleHint },
          ),
          signal: controller.signal,
        });

        if (seq !== this.narrationSeq) return;

        if (res.ok) {
          const data = (await res.json()) as { audioBase64?: string };
          if (data.audioBase64 && seq === this.narrationSeq) {
            if (this.clientTtsCache.size >= 60) {
              const oldest = this.clientTtsCache.keys().next().value;
              if (oldest) this.clientTtsCache.delete(oldest);
            }
            this.clientTtsCache.set(cacheKey, data.audioBase64);

            const played = await this.playWavBase64(data.audioBase64, seq, options?.onEnd);
            if (played || seq !== this.narrationSeq) return;
          }
        }
      } catch {
        if (seq !== this.narrationSeq) return;
        // Cleanly fall back to sentence-paced ms-MY SpeechSynthesis below
      } finally {
        if (this.ttsAbortController === controller) {
          this.ttsAbortController = null;
        }
      }
    }

    if (seq !== this.narrationSeq) return;

    // 3. Natural sentence-paced Malaysian Malay browser SpeechSynthesis fallback
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const voices = await this.loadSpeechVoices();
      if (seq !== this.narrationSeq) return;

      const selectedVoice = this.pickMalaysianVoice(voices, profile.gender);
      const sentences = spokenText
        .split(/(?<=[.!?])\s+/)
        .map((s) => s.trim())
        .filter(Boolean);
      const chunks = sentences.length > 0 ? sentences : [spokenText];

      const speakChunk = (idx: number) => {
        if (seq !== this.narrationSeq) return;
        if (idx >= chunks.length) {
          this.setSpeakingState(false);
          this.duckMusic(false);
          options?.onEnd?.();
          return;
        }

        const utter = new SpeechSynthesisUtterance(chunks[idx]);
        if (selectedVoice) {
          utter.voice = selectedVoice;
        }
        utter.lang = 'ms-MY';
        utter.pitch = options?.pitch ?? profile.fallbackPitch;
        utter.rate = options?.rate ?? profile.fallbackRate;
        utter.volume = Math.min(1, Math.max(0, this.settings.narrationVolume * this.settings.masterVolume));
        utter.onend = () => {
          if (seq !== this.narrationSeq) return;
          window.setTimeout(() => speakChunk(idx + 1), 135);
        };
        utter.onerror = () => {
          if (seq !== this.narrationSeq) return;
          this.setSpeakingState(false);
          this.duckMusic(false);
          options?.onEnd?.();
        };
        window.speechSynthesis.speak(utter);
      };

      speakChunk(0);
    } else {
      globalThis.setTimeout(() => {
        if (seq !== this.narrationSeq) return;
        this.setSpeakingState(false);
        this.duckMusic(false);
        options?.onEnd?.();
      }, 2200);
    }
  }
}

export const soundEngine = new SoundEngine();
